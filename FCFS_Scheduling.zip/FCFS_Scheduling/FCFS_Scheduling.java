import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FCFS_Scheduling {

    // Class to represent each process
    static class Process {
        String processId;
        int arrivalTime;
        int burstTime;
        int waitingTime;
        int turnaroundTime;

        Process(String processId, int arrivalTime, int burstTime) {
            this.processId = processId;
            this.arrivalTime = arrivalTime;
            this.burstTime = burstTime;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FCFS_GUI().setVisible(true));
    }

    static class FCFS_GUI extends JFrame {
        private final DefaultTableModel tableModel;
        private final List<Process> processList;

        public FCFS_GUI() {
            processList = new ArrayList<>();
            setTitle("FCFS Scheduling Algorithm");
            setSize(600, 500);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);

            // Panel for user input
            JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
            inputPanel.setBorder(BorderFactory.createTitledBorder("Add Process"));

            JLabel lblProcessId = new JLabel("Process ID:");
            JTextField txtProcessId = new JTextField();
            JLabel lblArrivalTime = new JLabel("Arrival Time:");
            JTextField txtArrivalTime = new JTextField();
            JLabel lblBurstTime = new JLabel("Burst Time:");
            JTextField txtBurstTime = new JTextField();

            JButton btnAddProcess = new JButton("Add Process");
            inputPanel.add(lblProcessId);
            inputPanel.add(txtProcessId);
            inputPanel.add(lblArrivalTime);
            inputPanel.add(txtArrivalTime);
            inputPanel.add(lblBurstTime);
            inputPanel.add(txtBurstTime);
            inputPanel.add(new JLabel()); // Empty space for alignment
            inputPanel.add(btnAddProcess);

            // Table to display process details
            tableModel = new DefaultTableModel(new Object[]{"Process ID", "Arrival Time", "Burst Time", "Waiting Time", "Turnaround Time"}, 0);
            JTable processTable = new JTable(tableModel);
            JScrollPane tableScrollPane = new JScrollPane(processTable);

            // Panel for results
            JPanel resultsPanel = new JPanel(new BorderLayout());
            resultsPanel.setBorder(BorderFactory.createTitledBorder("Results"));

            JTextArea resultsArea = new JTextArea();
            resultsArea.setEditable(false);
            resultsPanel.add(new JScrollPane(resultsArea), BorderLayout.CENTER);

            JButton btnCalculate = new JButton("Calculate");
            resultsPanel.add(btnCalculate, BorderLayout.SOUTH);

            // Main layout
            setLayout(new BorderLayout(10, 10));
            add(inputPanel, BorderLayout.NORTH);
            add(tableScrollPane, BorderLayout.CENTER);
            add(resultsPanel, BorderLayout.SOUTH);

            // Action to add process
            btnAddProcess.addActionListener(e -> {
                String processId = txtProcessId.getText().trim();
                String arrivalTimeStr = txtArrivalTime.getText().trim();
                String burstTimeStr = txtBurstTime.getText().trim();

                // Validate inputs
                if (processId.isEmpty() || arrivalTimeStr.isEmpty() || burstTimeStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int arrivalTime = Integer.parseInt(arrivalTimeStr);
                    int burstTime = Integer.parseInt(burstTimeStr);

                    if (arrivalTime < 0 || burstTime < 0) {
                        JOptionPane.showMessageDialog(this, "Arrival and Burst Times must be non-negative.", "Input Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    processList.add(new Process(processId, arrivalTime, burstTime));
                    tableModel.addRow(new Object[]{processId, arrivalTime, burstTime, "-", "-"});
                    txtProcessId.setText("");
                    txtArrivalTime.setText("");
                    txtBurstTime.setText("");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Arrival Time and Burst Time must be integers.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            // Action to calculate results
            btnCalculate.addActionListener(e -> {
                if (processList.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No processes to calculate.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Sort processes by arrival time
                processList.sort(Comparator.comparingInt(p -> p.arrivalTime));

                // Calculate waiting time and turnaround time
                int currentTime = 0;
                double totalWaitingTime = 0;
                double totalTurnaroundTime = 0;

                for (Process process : processList) {
                    if (currentTime < process.arrivalTime) {
                        currentTime = process.arrivalTime;
                    }

                    process.waitingTime = currentTime - process.arrivalTime;
                    process.turnaroundTime = process.waitingTime + process.burstTime;

                    currentTime += process.burstTime;

                    totalWaitingTime += process.waitingTime;
                    totalTurnaroundTime += process.turnaroundTime;
                }

                // Update table with results
                tableModel.setRowCount(0);
                for (Process process : processList) {
                    tableModel.addRow(new Object[]{process.processId, process.arrivalTime, process.burstTime, process.waitingTime, process.turnaroundTime});
                }

                // Display results
                double avgWaitingTime = totalWaitingTime / processList.size();
                double avgTurnaroundTime = totalTurnaroundTime / processList.size();

                resultsArea.setText("Order of Execution: ");
                for (Process process : processList) {
                    resultsArea.append(process.processId + " ");
                }

                resultsArea.append("\n\nAverage Waiting Time: " + String.format("%.2f", avgWaitingTime));
                resultsArea.append("\nAverage Turnaround Time: " + String.format("%.2f", avgTurnaroundTime));
            });
        }
    }
}
